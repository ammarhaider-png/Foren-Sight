"""Correlation engine: three transparent, rule-based detections.

Rule 1  Possible brute force
        3+ failed logins, then a successful login, for the same user (and the same IP when both
        events have one), all inside 5 minutes.
Rule 2  Possible privilege abuse
        successful login -> special privileges assigned -> object access, in that order, for the
        same user (and the same Windows logon session when known), within 10 minutes of the login.
Rule 3  Suspicious data/object activity
        5+ object accesses touching 3+ different objects inside 2 minutes by one user, with a
        process started by that user within 2 minutes of that burst.

The thresholds below are the knobs for trading false positives against false negatives.
Findings are leads for an investigator, never proof.
"""
from collections import defaultdict
from datetime import timedelta

from .normalizer import (FAILED_LOGIN, OBJECT_ACCESS, PROCESS_CREATED, SPECIAL_PRIVILEGES_ASSIGNED,
                         SUCCESSFUL_LOGIN)

BRUTE_FORCE_MIN_FAILURES = 3
BRUTE_FORCE_WINDOW = timedelta(minutes=5)
PRIVILEGE_WINDOW = timedelta(minutes=10)
OBJECT_BURST_WINDOW = timedelta(minutes=2)
OBJECT_BURST_MIN_ACCESSES = 5
OBJECT_BURST_MIN_DISTINCT = 3
PROCESS_MARGIN = timedelta(minutes=2)
MAX_EVENTS_SHOWN = 25

# Accounts that generate constant background activity. Their events stay on the timeline but are not 
# fed to the rules, because they would trigger endless false alarms.

BACKGROUND_ACCOUNTS = frozenset({"system", "local service", "network service", "anonymous logon"})
RULE_EVENT_TYPES = frozenset({FAILED_LOGIN, SUCCESSFUL_LOGIN, SPECIAL_PRIVILEGES_ASSIGNED,
                              OBJECT_ACCESS, PROCESS_CREATED})
_SEVERITY_RANK = {"High": 0, "Medium": 1, "Low": 2}


class Findings(list):
    """List of findings plus notes about what the rules could not examine."""

    def __init__(self, items=(), notes=None):
        super().__init__(items)
        self.notes = list(notes or [])


def _is_background(user):
    name = user.lower()
    return name in BACKGROUND_ACCOUNTS or name.endswith("$") or name.startswith(("dwm-", "umfd-"))


def _ip_compatible(a, b):
    return not (a["source_ip"] and b["source_ip"]) or a["source_ip"] == b["source_ip"]


def _same_session(a, b):
    return not (a["session"] and b["session"]) or a["session"] == b["session"]


def _span(first, last):
    seconds = int((last["time"] - first["time"]).total_seconds())
    return f"{seconds // 60} min {seconds % 60} s" if seconds >= 60 else f"{seconds} s"


def _finding(rule_id, rule, severity, explanation, events, user="", ip="", target=""):
    shown = events[:MAX_EVENTS_SHOWN]
    if len(events) > len(shown):
        explanation += f" Showing the first {len(shown)} of {len(events)} events."
    return {"rule_id": rule_id, "rule": rule, "severity": severity, "explanation": explanation,
            "user": user, "source_ip": ip, "target": target,
            "start": events[0]["timestamp"], "end": events[-1]["timestamp"],
            "events": shown, "all_events": events, "event_count": len(events)}


# ---------- Rule 1 ----------
def _brute_force(events):
    buckets = defaultdict(list)
    for e in events:
        if e["event_type"] not in (FAILED_LOGIN, SUCCESSFUL_LOGIN):
            continue
        if e["user"] and _is_background(e["user"]):
            continue
        key = e["user"].lower() or (f"ip:{e['source_ip']}" if e["source_ip"] else None)
        if key:  # events with neither user nor IP cannot be linked to anything
            buckets[key].append(e)

    results = []
    for items in buckets.values():
        pending = []
        for e in items:
            if e["event_type"] == FAILED_LOGIN:
                pending.append(e)
                continue
            pending = [f for f in pending if f["time"] >= e["time"] - BRUTE_FORCE_WINDOW]
            hits = [f for f in pending if _ip_compatible(f, e)]
            if len(hits) < BRUTE_FORCE_MIN_FAILURES:
                continue
            count = len(hits)
            severity = "High" if count >= 10 else "Medium" if count >= 5 else "Low"
            who = f"'{e['user']}'" if e["user"] else f"IP {e['source_ip']}"
            origin = f" from {e['source_ip']}" if e["user"] and e["source_ip"] else ""
            text = (f"{count} failed logins for {who}{origin} between {hits[0]['timestamp']} and "
                    f"{hits[-1]['timestamp']}, followed by a successful login at {e['timestamp']} "
                    f"(all within {_span(hits[0], e)}). This can mean a password was guessed, but it can also "
                    "be a legitimate user mistyping a password.")
            results.append((_finding("RULE_1", "Possible brute force", severity, text, hits + [e],
                                     user=e["user"], ip=e["source_ip"], target=e["target"]), e))
            used = {id(f) for f in hits}
            pending = [f for f in pending if id(f) not in used]
    return results


# ---------- Rule 2 ----------
def _privilege_sequences(events, brute_force_logins):
    by_user = defaultdict(list)
    for e in events:
        if e["event_type"] in (SUCCESSFUL_LOGIN, SPECIAL_PRIVILEGES_ASSIGNED, OBJECT_ACCESS) \
                and e["user"] and not _is_background(e["user"]):
            by_user[e["user"].lower()].append(e)

    findings = []
    for items in by_user.values():
        used = set()
        for i, login in enumerate(items):
            if login["event_type"] != SUCCESSFUL_LOGIN or id(login) in used:
                continue
            deadline = login["time"] + PRIVILEGE_WINDOW
            priv_at = None
            for j in range(i + 1, len(items)):
                e = items[j]
                if e["time"] > deadline:
                    break
                if e["event_type"] == SPECIAL_PRIVILEGES_ASSIGNED and id(e) not in used and _same_session(login, e):
                    priv_at = j
                    break
            if priv_at is None:
                continue
            objects = []
            for e in items[priv_at + 1:]:
                if e["time"] > deadline:
                    break
                if e["event_type"] == OBJECT_ACCESS and _same_session(login, e):
                    objects.append(e)
            if not objects:
                continue
            priv = items[priv_at]
            used.update((id(login), id(priv)))
            chained = id(login) in brute_force_logins
            text = (f"'{login['user']}' logged in at {login['timestamp']}, was assigned special privileges at "
                    f"{priv['timestamp']}, and accessed {len(objects)} object(s) within {_span(login, objects[-1])} "
                    "of the login. Administrators do this routinely, so verify whether it was authorized.")
            if chained:
                text += " The login also followed a possible brute-force pattern, which raises the severity."
            findings.append(_finding("RULE_2", "Possible privilege abuse", "High" if chained else "Medium", text,
                                     [login, priv] + objects, user=login["user"], ip=login["source_ip"],
                                     target=objects[0]["target"]))
    return findings


# ---------- Rule 3 ----------
def _object_bursts(events):
    objects, processes = defaultdict(list), defaultdict(list)
    for e in events:
        if not e["user"] or _is_background(e["user"]):
            continue
        if e["event_type"] == OBJECT_ACCESS:
            objects[e["user"].lower()].append(e)
        elif e["event_type"] == PROCESS_CREATED:
            processes[e["user"].lower()].append(e)

    findings = []
    for user, accesses in objects.items():
        spans, end = [], 0
        for start in range(len(accesses)):
            end = max(end, start)
            while end + 1 < len(accesses) and accesses[end + 1]["time"] - accesses[start]["time"] <= OBJECT_BURST_WINDOW:
                end += 1
            window = accesses[start:end + 1]
            distinct = {a["target"].lower() for a in window if a["target"]}
            if len(window) >= OBJECT_BURST_MIN_ACCESSES and len(distinct) >= OBJECT_BURST_MIN_DISTINCT:
                if spans and start <= spans[-1][1]:
                    spans[-1][1] = max(spans[-1][1], end)  # overlapping windows are one burst
                else:
                    spans.append([start, end])
        for first, last in spans:
            burst = accesses[first:last + 1]
            lo, hi = burst[0]["time"] - PROCESS_MARGIN, burst[-1]["time"] + PROCESS_MARGIN
            started = [p for p in processes.get(user, []) if lo <= p["time"] <= hi]
            if not started:
                continue
            distinct = len({a["target"].lower() for a in burst if a["target"]})
            text = (f"'{burst[0]['user']}' accessed {len(burst)} objects ({distinct} different) within "
                    f"{_span(burst[0], burst[-1])} and started {len(started)} process(es) around the same time. "
                    "This can indicate bulk data collection, but backups, searches and normal work can look similar.")
            ordered = sorted(burst + started, key=lambda e: e["time"])
            others = f" and {distinct - 1} others" if distinct > 1 else ""
            findings.append(_finding("RULE_3", "Suspicious data/object activity",
                                     "High" if distinct >= 15 else "Medium", text, ordered,
                                     user=burst[0]["user"], target=burst[0]["target"] + others))
    return findings


def run_rules(events):
    events = sorted(events, key=lambda e: e["time"])
    brute = _brute_force(events)
    findings = [f for f, _ in brute]
    findings += _privilege_sequences(events, {id(login) for _, login in brute})
    findings += _object_bursts(events)
    findings.sort(key=lambda f: (_SEVERITY_RANK[f["severity"]], f["start"]))

    notes = []
    skipped = sum(1 for e in events if e["event_type"] in RULE_EVENT_TYPES and e["user"] and _is_background(e["user"]))
    if skipped:
        notes.append(f"{skipped} event(s) from system or service accounts were kept on the timeline but left out of "
                     "the detection rules to avoid false alarms.")
    if any(e["event_type"] == OBJECT_ACCESS for e in events) and not any(e["event_type"] == PROCESS_CREATED for e in events):
        notes.append("This file has object-access events but no process-creation events (Event ID 4688), so the "
                     "object-activity rule could not look for related process activity.")
    return Findings(findings, notes)
