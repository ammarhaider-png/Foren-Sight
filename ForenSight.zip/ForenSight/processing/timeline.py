"""Timeline: one chronological list of events from every source."""


def build_timeline(events):
    """Sort by UTC time. The sort is stable, so events with the same timestamp keep the order
    they had in the file (important for events logged in the same second). Nothing is removed
    or merged: repeated identical events can be real repeated attempts."""
    return sorted(events, key=lambda e: e["time"])
