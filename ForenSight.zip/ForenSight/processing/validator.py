"""Validator: decides Recognized / Partially recognized / Unrecognized and explains why.

Returns {"state", "label", "message", "missing", "warnings"}.
`missing` lists only fields whose absence switches off a detection capability.
"""
from parsers import EXPECTED_FIELDS, listed

from .normalizer import KNOWN_ACTIVITIES, normalize_activity, parse_time

_LABELS = {"recognized": "Recognized", "partial": "Partially recognized", "unrecognized": "Unrecognized"}
SUPPORTED_IDS = "4624, 4625, 4672, 4663, 4688"


def _result(state, message, missing=None, warnings=None):
    return {"state": state, "label": _LABELS[state], "message": message,
            "missing": list(missing or []), "warnings": list(warnings or [])}


def _timestamp_check(records):
    unreadable, no_zone = [], 0
    for rec in records:
        moment, assumed = parse_time(rec.get("Timestamp"))
        if moment is None:
            unreadable.append(rec.get("_ref", "?"))
        elif assumed:
            no_zone += 1
    return unreadable, no_zone


def _validate_evtx(records):
    unreadable, _ = _timestamp_check(records)
    if len(unreadable) == len(records):
        return _result("unrecognized", "None of the events had a readable timestamp.")
    usable = len(records) - len(unreadable)
    if unreadable:
        return _result("partial", f"{usable} supported Security events were found; some could not be used.",
                       warnings=[f"{len(unreadable)} event(s) were left out because their timestamp could not be read."])
    return _result("recognized", f"{usable} supported Windows Security events were found.")


def _validate_generic(records):
    present = {f for f in EXPECTED_FIELDS if any(r.get(f) for r in records)}
    expected = ", ".join(EXPECTED_FIELDS)
    if "Timestamp" not in present:
        return _result("unrecognized", "No Timestamp values were found, so events cannot be placed on a timeline. "
                                       f"Expected columns: {expected}.")
    if "Activity" not in present:
        return _result("unrecognized", f"No Activity values were found, so events cannot be classified. "
                                       f"Expected columns: {expected}.")
    unreadable, no_zone = _timestamp_check(records)
    if len(unreadable) == len(records):
        return _result("unrecognized", "None of the Timestamp values could be read. "
                                       "Use a year-first format such as 2026-03-14 10:02:10.")

    warnings, consequences = [], []
    has_user, has_ip, has_target = ("User" in present, "Ip Address" in present, "Target" in present)
    missing = [name for name, ok in (("User", has_user), ("Ip Address", has_ip), ("Target", has_target)) if not ok]
    if not has_user and not has_ip:
        consequences.append("Brute-force detection is unavailable (it needs a User or an Ip Address).")
    elif not has_user:
        consequences.append("Brute-force detection can only group attempts by Ip Address.")
    elif not has_ip:
        consequences.append("Brute-force detection can only group attempts by User.")
    if not has_user:
        consequences.append("The privilege-abuse and object-activity rules are unavailable (they need a User).")
    elif not has_target:
        consequences.append("The object-activity rule is unavailable (it needs a Target).")

    activities = [normalize_activity(r.get("Activity")) for r in records]
    unknown = [a for a in activities if a not in KNOWN_ACTIVITIES]
    if len(unknown) == len(activities):
        consequences.append("No Activity value matches a type the rules use (" + ", ".join(sorted(KNOWN_ACTIVITIES))
                            + "), so no detection rules can run. The timeline will still be built.")
    elif unknown:
        example = next((a for a in unknown if a), "")
        warnings.append(f"{len(unknown)} event(s) have Activity values the rules do not use"
                        + (f" (for example {example})" if example else "") + "; they appear on the timeline only.")

    if unreadable:
        warnings.insert(0, f"{len(unreadable)} of {len(records)} events were left out because their timestamp "
                           f"could not be read ({listed(unreadable)}). Use a year-first format such as 2026-03-14 10:02:10.")
    if no_zone:
        warnings.append(f"{no_zone} timestamp(s) had no time zone and were treated as UTC. Sources only line up "
                        "correctly when they use the same time zone.")

    if consequences or unreadable:
        message = " ".join(consequences) or "Some events could not be used."
        result = _result("partial", message, missing, warnings)
    else:
        result = _result("recognized", "All required fields were found.", warnings=warnings)
    result["naive_timestamps"] = no_zone  # how many timestamps had no time zone (treated as UTC)
    return result


def validate(records, file_type):
    if not records:
        if file_type == "evtx":
            return _result("unrecognized", "No supported Windows Security events were found "
                                           f"(supported Event IDs: {SUPPORTED_IDS}).")
        return _result("unrecognized", "No events were found in this file. Expected columns: "
                                       + ", ".join(EXPECTED_FIELDS) + ".")
    return _validate_evtx(records) if file_type == "evtx" else _validate_generic(records)
