"""Normalizer: raw records -> events that all share one shape.

Every event is a dict:
    timestamp    display text, UTC ("2026-03-14 10:02:10")
    time         timezone-aware datetime (UTC) used for ordering and rules
    source       machine / log source           (normalized field "Source")
    event_type   FAILED_LOGIN, OBJECT_ACCESS... (normalized field "Event Type")
    user, source_ip, target, details            (normalized fields)
    session      Windows logon session, when known (lets rules link events of one session)
    event_id     Windows Event ID, or None
    ref          where it came from in the file ("line 5", "record 7712")

Time zone rule: timestamps WITHOUT a zone are treated as UTC (and the validator says so).
Records whose timestamp cannot be read are left out; the validator reports how many.
"""
import ipaddress
import re
from datetime import datetime, timedelta, timezone

FAILED_LOGIN = "FAILED_LOGIN"
SUCCESSFUL_LOGIN = "SUCCESSFUL_LOGIN"
SPECIAL_PRIVILEGES_ASSIGNED = "SPECIAL_PRIVILEGES_ASSIGNED"
OBJECT_ACCESS = "OBJECT_ACCESS"
PROCESS_CREATED = "PROCESS_CREATED"
KNOWN_ACTIVITIES = frozenset({FAILED_LOGIN, SUCCESSFUL_LOGIN, SPECIAL_PRIVILEGES_ASSIGNED,
                              OBJECT_ACCESS, PROCESS_CREATED})

EVENT_ID_ACTIVITY = {4624: SUCCESSFUL_LOGIN, 4625: FAILED_LOGIN, 4672: SPECIAL_PRIVILEGES_ASSIGNED,
                     4663: OBJECT_ACCESS, 4688: PROCESS_CREATED}

LOGON_TYPES = {"2": "Interactive", "3": "Network", "4": "Batch", "5": "Service", "7": "Unlock",
               "8": "NetworkCleartext", "9": "NewCredentials", "10": "RemoteInteractive",
               "11": "CachedInteractive"}

FAILURE_REASONS = {"0xc000006a": "wrong password", "0xc0000064": "unknown user name",
                   "0xc000006d": "logon failure", "0xc0000234": "account locked out",
                   "0xc0000072": "account disabled", "0xc0000071": "password expired",
                   "0xc000006e": "account restriction", "0xc0000070": "workstation restriction",
                   "0xc000006f": "outside permitted hours"}

_PLACEHOLDERS = {"", "-", "n/a", "null", "none"}
_TIME = re.compile(r"^(\d{4})[-/](\d{2})[-/](\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?"
                   r"(?:[.,](\d{1,9}))?\s*(Z|[+-]\d{2}:?\d{2})?$", re.I)


def clean(value):
    """Strip whitespace and treat placeholders such as '-' as empty."""
    text = str(value if value is not None else "").strip()
    return "" if text.lower() in _PLACEHOLDERS else text


def normalize_activity(value):
    """'Failed Login' / 'failed-login' -> 'FAILED_LOGIN'. Only formatting is fixed, never meaning."""
    text = re.sub(r"[\s\-]+", "_", str(value or "").strip()).upper()
    return re.sub(r"_+", "_", text).strip("_")


def normalize_ip(value):
    """Canonical IP text so '::ffff:10.0.0.5' and '10.0.0.5' match. Non-IP text is kept as written."""
    text = clean(value)
    if not text:
        return ""
    try:
        ip = ipaddress.ip_address(text.split("%")[0])
    except ValueError:
        return text
    if ip.version == 6 and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return str(ip)


def parse_time(value):
    """-> (aware UTC datetime or None, assumed_utc). Only unambiguous formats are accepted:
    ISO-like year-first timestamps (zone optional) and Unix epoch seconds/milliseconds.
    Day/month formats such as 03/04/2026 are refused because they cannot be told apart."""
    text = str(value if value is not None else "").strip()
    if not text:
        return None, False
    try:
        match = _TIME.match(text)
        if match:
            y, mo, d, h, mi, s, frac, zone = match.groups()
            moment = datetime(int(y), int(mo), int(d), int(h), int(mi), int(s or 0),
                              int((frac or "0")[:6].ljust(6, "0")), tzinfo=timezone.utc)
            if zone and zone.upper() != "Z":
                digits = zone[1:].replace(":", "")
                offset = timedelta(hours=int(digits[:2]), minutes=int(digits[2:]))
                moment -= offset if zone[0] == "+" else -offset
            return moment, zone is None
        if re.fullmatch(r"\d{10}(\.\d+)?", text):
            return datetime.fromtimestamp(float(text), timezone.utc), False
        if re.fullmatch(r"\d{13}", text):
            return datetime.fromtimestamp(int(text) / 1000, timezone.utc), False
    except (ValueError, OverflowError, OSError):
        pass
    return None, False


def format_time(moment):
    text = moment.strftime("%Y-%m-%d %H:%M:%S")
    return text + (f".{moment.microsecond // 1000:03d}" if moment.microsecond else "")


def _make(moment, source, event_type, user, ip, target, details, session="", event_id=None, ref=""):
    return {"timestamp": format_time(moment), "time": moment, "source": source, "event_type": event_type,
            "user": user, "source_ip": ip, "target": target, "details": details,
            "session": session, "event_id": event_id, "ref": ref}


def _generic_event(rec):
    moment, _ = parse_time(rec.get("Timestamp"))
    if moment is None:
        return None
    return _make(moment, clean(rec.get("System")), normalize_activity(rec.get("Activity")),
                 clean(rec.get("User")), normalize_ip(rec.get("Ip Address")), clean(rec.get("Target")),
                 str(rec.get("Details") or "").strip(), ref=rec.get("_ref", ""))


def _join(*parts):
    return "; ".join(p for p in parts if p)


def _evtx_event(rec):
    moment, _ = parse_time(rec.get("Timestamp"))
    if moment is None:
        return None
    event_id = rec["EventID"]
    data = rec.get("EventData", {})
    computer = rec.get("Computer", "")

    def field(name):
        return clean(data.get(name, ""))

    def session(name):
        logon_id = field(name).lower()
        return "" if logon_id in ("", "0x0") else f"{computer}:{logon_id}"

    user = ip = target = details = sess = ""
    if event_id in (4624, 4625):
        # TargetUserName is the account that logged on. SubjectUserName is usually the
        # machine account that reported the event, so it must NOT be used here.
        user, ip, target = field("TargetUserName"), normalize_ip(field("IpAddress")), computer
        logon_type = field("LogonType")
        type_text = f"Logon type {logon_type} ({LOGON_TYPES[logon_type]})" if logon_type in LOGON_TYPES \
            else (f"Logon type {logon_type}" if logon_type else "")
        if event_id == 4624:
            details = _join(type_text, f"workstation {field('WorkstationName')}" if field("WorkstationName") else "",
                            f"auth {field('AuthenticationPackageName')}" if field("AuthenticationPackageName") else "")
            sess = session("TargetLogonId")
        else:
            reason = FAILURE_REASONS.get(field("SubStatus").lower()) or FAILURE_REASONS.get(field("Status").lower())
            codes = "/".join(c for c in (field("Status"), field("SubStatus")) if c)
            details = _join(type_text, f"reason: {reason}" if reason else "", f"status {codes}" if codes else "")
    elif event_id == 4672:
        user, target, sess = field("SubjectUserName"), computer, session("SubjectLogonId")
        privileges = ", ".join(data.get("PrivilegeList", "").split())
        details = f"Privileges: {privileges}" if privileges else ""
    elif event_id == 4663:
        user, target, sess = field("SubjectUserName"), field("ObjectName"), session("SubjectLogonId")
        details = _join(field("ObjectType"), f"process {field('ProcessName')}" if field("ProcessName") else "",
                        f"access mask {field('AccessMask')}" if field("AccessMask") else "")
    elif event_id == 4688:
        user, target, sess = field("SubjectUserName"), field("NewProcessName"), session("SubjectLogonId")
        details = _join(f"parent {field('ParentProcessName')}" if field("ParentProcessName") else "",
                        f"command line: {field('CommandLine')}" if field("CommandLine") else "")
    return _make(moment, computer, EVENT_ID_ACTIVITY[event_id], user, ip, target, details,
                 session=sess, event_id=event_id, ref=rec.get("_ref", ""))


def normalize(records, file_type):
    build = _evtx_event if file_type == "evtx" else _generic_event
    return [event for event in (build(r) for r in records) if event is not None]
