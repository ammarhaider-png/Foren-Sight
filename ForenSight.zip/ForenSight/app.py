"""ForenSight: Flask entry point.

Connects the website to the processing pipeline:
Upload -> Parse -> Validate -> Normalize -> Timeline -> Correlate -> Display -> PDF.
Findings are shown on the Analyze page; the Timeline page shows all events.
Analysis results are kept in memory only (no database, no stored evidence).
"""
import io
import os
import uuid
from collections import OrderedDict

from flask import (Flask, flash, redirect, render_template, request,
                   send_file, session, url_for)

from parsers import ParseError

# The pipeline modules are built in later steps. Until they exist, the website
# still runs and shows a clear message when a file is uploaded.
try:
    from parsers.csv_parser import parse_csv
    from parsers.json_parser import parse_json
    from parsers.evtx_parser import parse_evtx
    from processing.validator import validate
    from processing.normalizer import normalize
    from processing.timeline import build_timeline
    from processing.correlation import run_rules
    PIPELINE_READY = True
except ImportError:
    PIPELINE_READY = False

try:
    from reports.pdf_report import build_pdf
    PDF_READY = True
except ImportError:
    PDF_READY = False

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", os.urandom(24))
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50 MB upload limit

# Warn at startup if the hero image is missing or misnamed
_img_dir = os.path.join(app.static_folder, "images")
if not os.path.exists(os.path.join(_img_dir, "forensic-workstation.jpg")):
    _found = os.listdir(_img_dir) if os.path.isdir(_img_dir) else "folder does not exist"
    print(f"[ForenSight] Hero image not found in {_img_dir}\n"
          f"             Files there: {_found}")

FILE_TYPES = {".csv": "csv", ".json": "json", ".jsonl": "json", ".ndjson": "json", ".evtx": "evtx"}
ALLOWED_EXTENSIONS = set(FILE_TYPES)
MAX_STORED_ANALYSES = 20
ANALYSES = OrderedDict()  # analysis id -> results, held in memory only


# ---------- helpers ----------
def run_pipeline(filename, data):
    """Run one uploaded file through the full pipeline.

    Expected module contracts:
      parse_*(bytes)                    -> ParsedRecords (a list of raw dicts + .warnings)
      validate(records, file_type)      -> dict(state, label, message, missing)
                                           state: recognized | partial | unrecognized
      normalize(records, file_type)     -> list[dict]  with the 7 standard fields
      build_timeline(events)            -> list[dict]  sorted chronologically
      run_rules(events)                 -> list[dict]  findings
    """
    file_type = FILE_TYPES[os.path.splitext(filename)[1].lower()]
    parser = {"csv": parse_csv, "json": parse_json, "evtx": parse_evtx}[file_type]

    records = parser(data)
    parse_notes = list(getattr(records, "warnings", []))  # what the parser skipped or repaired
    validation = dict(validate(records, file_type))
    validation["warnings"] = parse_notes + list(validation.get("warnings", []))
    validation["records_read"] = len(records)
    if validation["state"] == "unrecognized":
        return validation, [], []

    events = build_timeline(normalize(records, file_type))
    findings = run_rules(events)
    validation["warnings"] += list(getattr(findings, "notes", []))
    return validation, events, findings


def store_analysis(filename, validation, events, findings):
    aid = uuid.uuid4().hex
    ANALYSES[aid] = {"filename": filename, "validation": validation,
                     "events": events, "findings": findings}
    while len(ANALYSES) > MAX_STORED_ANALYSES:
        ANALYSES.popitem(last=False)  # drop the oldest
    session["aid"] = aid


def current_analysis():
    return ANALYSES.get(session.get("aid"))


@app.context_processor
def asset_version():
    """Changes whenever CSS/JS change, so browsers never serve a stale copy."""
    try:
        v = int(max(os.path.getmtime(os.path.join(app.static_folder, p))
                    for p in ("css/style.css", "js/main.js")))
    except OSError:
        v = 0
    return {"asset_v": v}


# ---------- pages ----------
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "GET":
        return render_template("upload.html", analysis=current_analysis())

    session.pop("aid", None)  # a new attempt never shows the previous file's results
    file = request.files.get("evidence")
    if not file or not file.filename:
        flash("Choose a CSV, JSON or EVTX file to analyze.", "error")
        return redirect(url_for("upload"))

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        flash(f"Unsupported file type '{ext or 'none'}'. Upload a .csv, .json, .jsonl or .evtx file.", "error")
        return redirect(url_for("upload"))

    if not PIPELINE_READY:
        flash("The processing modules are not built yet, so this file could not be analyzed.", "warning")
        return redirect(url_for("upload"))

    try:
        validation, events, findings = run_pipeline(file.filename, file.read())
    except ParseError as exc:
        flash(str(exc), "error")
        return redirect(url_for("upload"))
    except Exception:
        app.logger.exception("Failed to process %s", file.filename)
        flash("The file could not be read. Check that it is a valid CSV, JSON or EVTX file.", "error")
        return redirect(url_for("upload"))

    if validation["state"] == "unrecognized":
        reasons = " ".join([validation["message"]] + validation["warnings"])
        flash(f"Unrecognized file: {reasons}", "error")
        return redirect(url_for("upload"))

    store_analysis(file.filename, validation, events, findings)
    return redirect(url_for("upload", _anchor="results"))


@app.route("/timeline")
def timeline():
    a = current_analysis()
    return render_template("timeline.html",
                           events=a["events"] if a else [],
                           validation=a["validation"] if a else None)


@app.route("/report.pdf")
def download_report():
    a = current_analysis()
    if not a:
        flash("Analyze a file before downloading a report.", "warning")
        return redirect(url_for("upload"))
    if not PDF_READY:
        flash("PDF reports are not built yet.", "warning")
        return redirect(url_for("upload", _anchor="results"))
    pdf_bytes = build_pdf(a["events"], a["findings"], a["validation"], a["filename"])
    return send_file(io.BytesIO(pdf_bytes), mimetype="application/pdf",
                     as_attachment=True, download_name="forensight_report.pdf")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/help")
def help_page():
    return render_template("help.html")


@app.errorhandler(413)
def too_large(_):
    flash("That file is larger than the 50 MB limit.", "error")
    return redirect(url_for("upload"))


if __name__ == "__main__":
    app.run(debug=True)
