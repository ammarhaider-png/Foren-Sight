"""PDF investigation report.

    build_pdf(events, findings, validation, filename) -> bytes

Everything that came from the uploaded file is escaped before it is placed in the PDF, so
characters such as < & > in a log line can never break or alter the report.
"""
import io
import os
from datetime import datetime, timezone
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from processing import correlation as rules

MAX_TIMELINE_ROWS = 2000
MARGIN = 40
CONTENT_WIDTH = A4[0] - 2 * MARGIN  # 515 pt

EVIDENCE_BG = colors.HexColor("#fdf3d7")
INK = colors.HexColor("#1c2230")
MUTED = colors.HexColor("#5b6577")
LINE = colors.HexColor("#cfd5e0")
HEADER_BG = colors.HexColor("#eef1f6")
SEVERITY_COLORS = {"High": colors.HexColor("#c0392b"), "Medium": colors.HexColor("#b7791f"),
                   "Low": colors.HexColor("#2f6fdb")}

# Unicode-capable fonts are used when found, so non-English user names and paths print correctly.
_FONT_CANDIDATES = [
    (r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\arialbd.ttf"),
    ("/Library/Fonts/Arial.ttf", "/Library/Fonts/Arial Bold.ttf"),
    ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
]
_fonts = None


def _get_fonts():
    global _fonts
    if _fonts is None:
        _fonts = ("Helvetica", "Helvetica-Bold")
        for regular, bold in _FONT_CANDIDATES:
            if os.path.exists(regular) and os.path.exists(bold):
                try:
                    pdfmetrics.registerFont(TTFont("FS-Regular", regular))
                    pdfmetrics.registerFont(TTFont("FS-Bold", bold))
                    pdfmetrics.registerFontFamily("FS-Regular", normal="FS-Regular", bold="FS-Bold")
                    _fonts = ("FS-Regular", "FS-Bold")
                    break
                except Exception:
                    continue
    return _fonts


def _styles():
    regular, bold = _get_fonts()
    base = ParagraphStyle("base", fontName=regular, fontSize=9.5, leading=13.5, textColor=INK)
    return {
        "base": base,
        "title": ParagraphStyle("title", parent=base, fontName=bold, fontSize=22, leading=26, spaceAfter=2),
        "subtitle": ParagraphStyle("subtitle", parent=base, fontSize=10.5, textColor=MUTED, spaceAfter=14),
        "h1": ParagraphStyle("h1", parent=base, fontName=bold, fontSize=14, leading=18, spaceBefore=14, spaceAfter=6),
        "h2": ParagraphStyle("h2", parent=base, fontName=bold, fontSize=12, leading=16, spaceAfter=3),
        "small": ParagraphStyle("small", parent=base, fontSize=8, leading=10.5),
        "smallbold": ParagraphStyle("smallbold", parent=base, fontName=bold, fontSize=8, leading=10.5, textColor=MUTED),
        "muted": ParagraphStyle("muted", parent=base, textColor=MUTED),
        "bullet": ParagraphStyle("bullet", parent=base, leftIndent=12, bulletIndent=2, spaceAfter=2),
    }


def _text(value, limit=None):
    text = "" if value is None else str(value).strip()
    if not text:
        text = "-"
    if limit and len(text) > limit:
        text = text[:limit - 1] + "…"
    return escape(text)


def _cell(value, style, limit=220):
    return Paragraph(_text(value, limit), style)


def _grid(rows, widths, styles, header=True, extra=None):
    table = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    commands = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
                ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
    if header:
        commands.append(("BACKGROUND", (0, 0), (-1, 0), HEADER_BG))
    commands += extra or []
    table.setStyle(TableStyle(commands))
    return table


def _page_decorations(canvas, doc):
    regular, _ = _get_fonts()
    canvas.saveState()
    canvas.setStrokeColor(LINE)
    canvas.line(MARGIN, 34, A4[0] - MARGIN, 34)
    canvas.setFont(regular, 7.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(MARGIN, 22, "ForenSight - for authorized forensic analysis. Findings are indicators, not proof of wrongdoing.")
    canvas.drawRightString(A4[0] - MARGIN, 22, f"Page {doc.page}")
    canvas.restoreState()


def _summary_block(findings, validation, events, styles):
    flow = []
    if findings:
        counts = {s: sum(1 for f in findings if f["severity"] == s) for s in ("High", "Medium", "Low")}
        parts = ", ".join(f"{n} {s}" for s, n in counts.items() if n)
        flow.append(Paragraph(f'<font color="#c0392b">Suspicious activity detected</font>', styles["h2"]))
        flow.append(Paragraph(_text(f"{len(findings)} potentially suspicious pattern(s) found ({parts}) across "
                                    f"{len(events)} events. Each finding below lists the events behind it."), styles["base"]))
    else:
        flow.append(Paragraph('<font color="#2f855a">No alerts</font>', styles["h2"]))
        flow.append(Paragraph(_text(f"{len(events)} events were analyzed and no detection rule was triggered. "
                                    "This does not guarantee that nothing happened: rule-based detection can miss "
                                    "activity outside its rules."), styles["base"]))
    return flow


def _finding_block(number, finding, styles):
    sev = finding["severity"]
    color = SEVERITY_COLORS.get(sev, INK).hexval()[2:]
    heading = Paragraph(f'{number}. {_text(finding["rule"])}  <font color="#{color}" size="9">[{_text(sev)} severity]</font>',
                        styles["h2"])
    explanation = Paragraph(_text(finding["explanation"]), styles["base"])
    facts = _grid([
        [_cell("User", styles["smallbold"]), _cell(finding["user"], styles["small"]),
         _cell("Source IP", styles["smallbold"]), _cell(finding["source_ip"], styles["small"])],
        [_cell("Affected target", styles["smallbold"]), _cell(finding["target"], styles["small"]),
         _cell("Time span", styles["smallbold"]), _cell(f'{finding["start"]}  to  {finding["end"]}  (UTC)', styles["small"])],
    ], [80, 175, 70, 190], styles, header=False)

    rows = [[_cell(h, styles["smallbold"]) for h in ("Timestamp (UTC)", "Event type", "User", "Source IP", "Target")]]
    for e in finding["events"]:
        rows.append([_cell(e["timestamp"], styles["small"]), _cell(e["event_type"], styles["small"]),
                     _cell(e["user"], styles["small"]), _cell(e["source_ip"], styles["small"]),
                     _cell(e["target"], styles["small"], 160)])
    table = _grid(rows, [95, 140, 50, 66, 164], styles)
    shown = len(finding["events"])
    total = finding.get("event_count", shown)
    note = [Paragraph(_text(f"Showing {shown} of {total} related events."), styles["muted"])] if total > shown else []
    # One finding = one block: its label, facts and event table are never split across two pages.
    return [KeepTogether([heading, explanation, Spacer(1, 5), facts, Spacer(1, 6),
                          Paragraph("Relevant events", styles["smallbold"]), Spacer(1, 2), table, *note]),
            Spacer(1, 14)]


def _rules_table(styles):
    minutes = lambda td: int(td.total_seconds() // 60)
    rows = [[_cell(h, styles["smallbold"]) for h in ("Rule", "Pattern that triggers it")],
            [_cell("Possible brute force", styles["small"]),
             _cell(f"{rules.BRUTE_FORCE_MIN_FAILURES}+ failed logins followed by a successful login for the same user "
                   f"(and the same IP when both events have one), within {minutes(rules.BRUTE_FORCE_WINDOW)} minutes.", styles["small"])],
            [_cell("Possible privilege abuse", styles["small"]),
             _cell("Successful login, then special privileges assigned, then object access, in that order, for the same "
                   f"user (and Windows logon session when known), within {minutes(rules.PRIVILEGE_WINDOW)} minutes of the login.", styles["small"])],
            [_cell("Suspicious data/object activity", styles["small"]),
             _cell(f"{rules.OBJECT_BURST_MIN_ACCESSES}+ object accesses on {rules.OBJECT_BURST_MIN_DISTINCT}+ different objects by one "
                   f"user within {minutes(rules.OBJECT_BURST_WINDOW)} minutes, with a process started by that user "
                   f"within {minutes(rules.PROCESS_MARGIN)} minutes of the burst.", styles["small"])]]
    return _grid(rows, [140, 375], styles)


def build_story(events, findings, validation, filename):
    """The report as a list of flowables (kept separate so its layout can be tested without rendering)."""
    styles = _styles()
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    validation = validation or {}
    story = [Paragraph("ForenSight Investigation Report", styles["title"]),
             Paragraph("Digital forensic event correlation and suspicious activity detection", styles["subtitle"])]

    read = validation.get("records_read")
    analyzed = len(events) if read in (None, len(events)) else f"{len(events)} (of {read} read from the file)"
    zone_note = "All times are UTC."
    if validation.get("naive_timestamps"):
        zone_note += f" {validation['naive_timestamps']} timestamp(s) had no time zone and were assumed to be UTC."
    meta = [("Evidence file", filename), ("Report generated", generated),
            ("Input status", validation.get("label", "-")), ("Events analyzed", analyzed),
            ("Findings", len(findings)), ("Time zone", zone_note)]
    story.append(_grid([[_cell(k, styles["smallbold"]), _cell(v, styles["small"], 300)] for k, v in meta],
                       [110, 405], styles, header=False))

    story.append(Paragraph("Summary", styles["h1"]))
    story += _summary_block(findings, validation, events, styles)

    notes = []
    if validation.get("message") and validation.get("state") != "recognized":
        notes.append(validation["message"])
    if validation.get("missing"):
        notes.append("Missing fields: " + ", ".join(validation["missing"]) + ".")
    notes += list(validation.get("warnings", []))
    if notes:
        story.append(Paragraph("Notes about this analysis", styles["h1"]))
        story += [Paragraph(_text(n, 600), styles["bullet"], bulletText="•") for n in notes]

    if findings:
        story.append(Paragraph("Findings", styles["h1"]))
        for number, finding in enumerate(findings, 1):
            story += _finding_block(number, finding, styles)

    story.append(KeepTogether([
        Paragraph("Detection rules used", styles["h1"]),
        _rules_table(styles),
        Spacer(1, 6),
        Paragraph("Detection is rule-based, so false positives and false negatives are possible. System and "
                  "service accounts are shown on the timeline but are not evaluated by the rules. Treat every "
                  "finding as a lead to verify, not a conclusion.", styles["muted"])]))

    # The timeline always starts on a page of its own.
    story.append(PageBreak())
    story.append(Paragraph("Event timeline", styles["h1"]))
    shown = events[:MAX_TIMELINE_ROWS]
    evidence = {id(e) for f in findings for e in f.get("all_events", f["events"])}
    story.append(Paragraph(_text(f"All {len(events)} events in chronological order, in UTC. "
                                 + ("Shaded rows are events used as evidence in a finding." if evidence else "")), styles["muted"]))
    story.append(Spacer(1, 6))
    rows = [[_cell(h, styles["smallbold"]) for h in ("Timestamp (UTC)", "Source", "Event type", "User", "Source IP", "Target")]]
    shading = []
    for index, e in enumerate(shown, 1):
        rows.append([_cell(e["timestamp"], styles["small"]), _cell(e["source"], styles["small"], 60),
                     _cell(e["event_type"], styles["small"]), _cell(e["user"], styles["small"]),
                     _cell(e["source_ip"], styles["small"]), _cell(e["target"], styles["small"], 140)])
        if id(e) in evidence:
            shading.append(("BACKGROUND", (0, index), (-1, index), EVIDENCE_BG))
    if shown:
        story.append(_grid(rows, [95, 66, 140, 50, 64, 100], styles, extra=shading))
    else:
        story.append(Paragraph("No events.", styles["muted"]))
    if len(events) > len(shown):
        story.append(Spacer(1, 4))
        story.append(Paragraph(_text(f"Showing the first {len(shown)} of {len(events)} events. The full timeline, "
                                     "including event details, is on the website."), styles["muted"]))
    return story


def build_pdf(events, findings, validation, filename):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=MARGIN,
                            bottomMargin=48, title="ForenSight Investigation Report", author="ForenSight")
    doc.build(build_story(events, findings, validation, filename),
              onFirstPage=_page_decorations, onLaterPages=_page_decorations)
    return buffer.getvalue()
