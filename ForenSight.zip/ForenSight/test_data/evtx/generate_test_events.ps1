# Creates real Security-log events for ForenSight testing and exports them to security.evtx.
#
# Run in an ADMINISTRATOR PowerShell, on a PC you own:
#     .\generate_test_events.ps1
#
# It makes a temporary local user, simulates 3 wrong passwords and 1 correct logon against
# this PC, exports the Security log next to this script, then deletes the user again.
# Red "System error 1326" messages are expected: they are the wrong-password attempts.
# The export contains ALL recent Security events from this PC, so keep the file private.

#Requires -RunAsAdministrator
$user = "fs_testuser"
$good = "Fs!Test-Pass-2026x"
$bad  = "WrongPassword-1"
$out  = Join-Path $PSScriptRoot "security.evtx"

try {
    net user $user $good /add | Out-Null
    net localgroup Administrators $user /add | Out-Null

    1..3 | ForEach-Object {
        net use \\localhost\IPC$ /user:$user $bad | Out-Null
        Start-Sleep -Seconds 2
    }
    net use \\localhost\IPC$ /user:$user $good | Out-Null
    net use \\localhost\IPC$ /delete | Out-Null
    Start-Sleep -Seconds 2

    wevtutil epl Security $out /ow:true
    Write-Host "Exported to $out"
}
finally {
    net localgroup Administrators $user /delete | Out-Null
    net user $user /delete | Out-Null
}
