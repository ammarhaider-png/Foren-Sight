"""Run from the project root:  python -m unittest discover -s test_data -v"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from parsers.csv_parser import parse_csv                      # noqa: E402
from parsers.json_parser import parse_json                    # noqa: E402
from processing.correlation import run_rules                  # noqa: E402
from processing.normalizer import (normalize, normalize_activity, normalize_ip,   # noqa: E402
                                   parse_time)
from processing.timeline import build_timeline                # noqa: E402
from processing.validator import validate                     # noqa: E402

HEAD = "Timestamp,System,Activity,User,Ip Address,Target,Details\n"
F, S, P, O, X = "FAILED_LOGIN", "SUCCESSFUL_LOGIN", "SPECIAL_PRIVILEGES_ASSIGNED", "OBJECT_ACCESS", "PROCESS_CREATED"


def csv_events(rows):
    """rows: (time, activity, user, ip, target) -> sorted events"""
    text = HEAD + "".join(f"2026-03-14 {t},host,{a},{u},{ip},{tg},x\n" for t, a, u, ip, tg in rows)
    return build_timeline(normalize(parse_csv(text.encode()), "csv"))


def run(rows):
    return run_rules(csv_events(rows))


def rule(findings, rule_id):
    return [f for f in findings if f["rule_id"] == rule_id]


def evtx_rec(event_id, ts, computer="PC", **data):
    return {"EventID": event_id, "Provider": "Microsoft-Windows-Security-Auditing", "Channel": "Security",
            "Computer": computer, "RecordID": "1", "Timestamp": ts, "EventData": data, "_ref": "record 1"}


def sample(*parts):
    with open(os.path.join(ROOT, "test_data", *parts), "rb") as f:
        return f.read()


class Rule1Tests(unittest.TestCase):
    A = ("jdoe", "10.0.0.5")

    def fails(self, times, user="jdoe", ip="10.0.0.5"):
        return [(t, F, user, ip, "SSH") for t in times]

    def test_detects_three_failures_then_success(self):
        r = run(self.fails(["10:02:10", "10:02:45", "10:03:12"]) + [("10:04:01", S, "jdoe", "10.0.0.5", "SSH")])
        found = rule(r, "RULE_1")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["severity"], "Low")
        self.assertEqual((found[0]["user"], found[0]["source_ip"]), self.A)
        self.assertEqual(len(found[0]["events"]), 4)
        self.assertEqual((found[0]["start"], found[0]["end"]), ("2026-03-14 10:02:10", "2026-03-14 10:04:01"))

    def test_two_failures_is_not_enough(self):
        self.assertEqual(run(self.fails(["10:02:10", "10:02:45"]) + [("10:04:01", S, "jdoe", "10.0.0.5", "")]), [])

    def test_no_success_no_finding(self):
        self.assertEqual(run(self.fails(["10:02:10", "10:02:45", "10:03:12", "10:03:30"])), [])

    def test_failures_older_than_window_do_not_count(self):
        r = run(self.fails(["10:00:00", "10:02:00", "10:04:30"]) + [("10:05:30", S, "jdoe", "10.0.0.5", "")])
        self.assertEqual(r, [])

    def test_different_ip_is_not_linked(self):
        r = run(self.fails(["10:02:10", "10:02:45", "10:03:12"]) + [("10:04:01", S, "jdoe", "10.0.0.99", "")])
        self.assertEqual(r, [])

    def test_different_users_same_ip_is_not_linked(self):
        rows = [("10:02:10", F, "a", "10.0.0.5", ""), ("10:02:45", F, "b", "10.0.0.5", ""),
                ("10:03:12", F, "c", "10.0.0.5", ""), ("10:04:01", S, "a", "10.0.0.5", "")]
        self.assertEqual(run(rows), [])

    def test_missing_ip_on_one_side_still_links_by_user(self):
        r = run(self.fails(["10:02:10", "10:02:45", "10:03:12"], ip="") + [("10:04:01", S, "jdoe", "10.0.0.5", "")])
        self.assertEqual(len(rule(r, "RULE_1")), 1)

    def test_ip_only_grouping_when_no_user(self):
        rows = [(t, F, "", "10.0.0.9", "") for t in ("10:02:10", "10:02:45", "10:03:12")] + [("10:04:01", S, "", "10.0.0.9", "")]
        self.assertEqual(len(rule(run(rows), "RULE_1")), 1)

    def test_user_case_insensitive_and_order_independent(self):
        rows = [("10:04:01", S, "JDOE", "10.0.0.5", "")] + self.fails(["10:03:12", "10:02:10", "10:02:45"])
        self.assertEqual(len(rule(run(rows), "RULE_1")), 1)

    def test_second_success_does_not_duplicate(self):
        rows = self.fails(["10:02:10", "10:02:45", "10:03:12"]) + [("10:04:01", S, "jdoe", "10.0.0.5", ""),
                                                                    ("10:04:30", S, "jdoe", "10.0.0.5", "")]
        self.assertEqual(len(rule(run(rows), "RULE_1")), 1)

    def test_severity_scales_with_failures(self):
        five = [f"10:0{i}:00" for i in range(5)]
        ten = [f"10:0{i}:{s}" for i in range(5) for s in ("00", "30")]
        self.assertEqual(rule(run(self.fails(five) + [("10:04:50", S, "jdoe", "10.0.0.5", "")]), "RULE_1")[0]["severity"], "Medium")
        self.assertEqual(rule(run(self.fails(ten) + [("10:04:50", S, "jdoe", "10.0.0.5", "")]), "RULE_1")[0]["severity"], "High")

    def test_background_accounts_ignored_but_reported(self):
        r = run(self.fails(["10:02:10", "10:02:45", "10:03:12"], user="SYSTEM") + [("10:04:01", S, "SYSTEM", "10.0.0.5", "")])
        self.assertEqual(r, [])
        self.assertTrue(any("system or service accounts" in n for n in r.notes))


class Rule2Tests(unittest.TestCase):
    def seq(self, o_time="09:02:00", o_user="jdoe"):
        return [("09:00:00", S, "jdoe", "10.0.0.5", "PC"), ("09:00:05", P, "jdoe", "", "PC"),
                (o_time, O, o_user, "", "C:/payroll.xlsx")]

    def test_detects_sequence(self):
        found = rule(run(self.seq()), "RULE_2")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["severity"], "Medium")
        self.assertEqual([e["event_type"] for e in found[0]["events"]], [S, P, O])

    def test_wrong_order(self):
        rows = [("09:00:00", S, "jdoe", "", ""), ("09:01:00", O, "jdoe", "", "f"), ("09:02:00", P, "jdoe", "", "")]
        self.assertEqual(rule(run(rows), "RULE_2"), [])

    def test_outside_window(self):
        self.assertEqual(rule(run(self.seq(o_time="09:15:00")), "RULE_2"), [])

    def test_other_users_access_does_not_count(self):
        self.assertEqual(rule(run(self.seq(o_user="someone")), "RULE_2"), [])

    def test_chain_with_brute_force_is_high(self):
        rows = [("08:57:10", F, "jdoe", "10.0.0.5", ""), ("08:57:45", F, "jdoe", "10.0.0.5", ""),
                ("08:58:12", F, "jdoe", "10.0.0.5", "")] + self.seq()
        r = run(rows)
        self.assertEqual(len(rule(r, "RULE_1")), 1)
        self.assertEqual(rule(r, "RULE_2")[0]["severity"], "High")

    def test_session_must_match_on_windows_logs(self):
        def build(object_session):
            recs = [evtx_rec(4624, "2026-03-14T10:00:00Z", TargetUserName="jdoe", TargetLogonId="0x1000", IpAddress="-"),
                    evtx_rec(4672, "2026-03-14T10:00:01Z", SubjectUserName="jdoe", SubjectLogonId="0x1000"),
                    evtx_rec(4663, "2026-03-14T10:01:00Z", SubjectUserName="jdoe", SubjectLogonId=object_session,
                             ObjectName="C:\\x.txt")]
            return run_rules(build_timeline(normalize(recs, "evtx")))
        self.assertEqual(len(rule(build("0x1000"), "RULE_2")), 1)
        self.assertEqual(rule(build("0x2000"), "RULE_2"), [])

    def test_machine_and_system_accounts_ignored(self):
        rows = [("09:00:00", S, "PC$", "", ""), ("09:00:05", P, "PC$", "", ""), ("09:01:00", O, "PC$", "", "f")]
        self.assertEqual(run(rows), [])


class Rule3Tests(unittest.TestCase):
    def burst(self, targets, step=15, user="jdoe"):
        rows = []
        for i, t in enumerate(targets):
            s = i * step
            rows.append((f"11:{s // 60:02d}:{s % 60:02d}", O, user, "", t))
        return rows

    FILES = ["a.txt", "b.txt", "c.txt", "d.txt", "e.txt"]

    def test_detects_burst_with_process(self):
        r = run(self.burst(self.FILES) + [("11:00:20", X, "jdoe", "", "cmd.exe")])
        found = rule(r, "RULE_3")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["severity"], "Medium")
        self.assertEqual(found[0]["event_count"], 6)

    def test_no_process_no_finding_but_noted(self):
        r = run(self.burst(self.FILES))
        self.assertEqual(r, [])
        self.assertTrue(any("4688" in n for n in r.notes))

    def test_too_few_distinct_objects(self):
        r = run(self.burst(["a", "b", "a", "b", "a"]) + [("11:00:20", X, "jdoe", "", "cmd.exe")])
        self.assertEqual(r, [])

    def test_spread_too_thin(self):
        r = run(self.burst(self.FILES, step=150) + [("11:00:20", X, "jdoe", "", "cmd.exe")])
        self.assertEqual(r, [])

    def test_process_by_someone_else_does_not_count(self):
        r = run(self.burst(self.FILES) + [("11:00:20", X, "other", "", "cmd.exe")])
        self.assertEqual(r, [])

    def test_long_activity_is_one_finding(self):
        r = run(self.burst([f"f{i}" for i in range(12)], step=20) + [("11:01:00", X, "jdoe", "", "cmd.exe")])
        self.assertEqual(len(rule(r, "RULE_3")), 1)


class NormalizerTests(unittest.TestCase):
    def test_parse_time(self):
        utc = parse_time("2026-03-14 10:02:10")
        self.assertEqual(utc[0].isoformat(), "2026-03-14T10:02:10+00:00")
        self.assertTrue(utc[1])
        self.assertEqual(parse_time("2026-03-14T11:02:10+01:00")[0].hour, 10)
        self.assertFalse(parse_time("2026-03-14T10:02:10Z")[1])
        self.assertEqual(parse_time("1773482530")[0].year, 2026)
        self.assertEqual(parse_time("1773482530000")[0].year, 2026)
        for bad in ("", "garbage", "03/04/2026 10:00:00", "2026-03-14", "2026-13-40 10:00:00", None):
            self.assertIsNone(parse_time(bad)[0], bad)

    def test_field_cleaning(self):
        self.assertEqual(normalize_activity("Failed Login"), "FAILED_LOGIN")
        self.assertEqual(normalize_activity(" failed-login "), "FAILED_LOGIN")
        self.assertEqual(normalize_ip("::ffff:192.168.1.5"), "192.168.1.5")
        self.assertEqual(normalize_ip("-"), "")
        self.assertEqual(normalize_ip("not-an-ip"), "not-an-ip")

    def test_unreadable_timestamps_left_out(self):
        text = HEAD + "yesterday,h,FAILED_LOGIN,a,,,\n2026-03-14 10:00:00,h,FAILED_LOGIN,a,,,\n"
        self.assertEqual(len(normalize(parse_csv(text.encode()), "csv")), 1)

    def test_windows_mapping(self):
        recs = [
            evtx_rec(4625, "2026-03-14T10:00:00Z", SubjectUserName="PC$", TargetUserName="jdoe", IpAddress="::ffff:10.0.0.5",
                     LogonType="3", Status="0xc000006d", SubStatus="0xc000006a"),
            evtx_rec(4672, "2026-03-14T10:00:02Z", SubjectUserName="jdoe", SubjectLogonId="0x1000",
                     PrivilegeList="SeDebugPrivilege\n\t\t\tSeBackupPrivilege"),
            evtx_rec(4663, "2026-03-14T10:00:03Z", SubjectUserName="jdoe", SubjectLogonId="0x1000", ObjectName="C:\\a.txt",
                     ObjectType="File", ProcessName="C:\\x.exe", AccessMask="0x2"),
            evtx_rec(4688, "2026-03-14T10:00:04Z", SubjectUserName="jdoe", NewProcessName="C:\\cmd.exe",
                     ParentProcessName="C:\\explorer.exe", CommandLine="cmd /c dir"),
        ]
        failed, priv, obj, proc = normalize(recs, "evtx")
        self.assertEqual((failed["event_type"], failed["user"], failed["source_ip"]), (F, "jdoe", "10.0.0.5"))
        self.assertIn("wrong password", failed["details"])
        self.assertIn("Network", failed["details"])
        self.assertEqual(priv["details"], "Privileges: SeDebugPrivilege, SeBackupPrivilege")
        self.assertEqual(priv["session"], "PC:0x1000")
        self.assertEqual((obj["target"], obj["event_id"]), ("C:\\a.txt", 4663))
        self.assertEqual((proc["event_type"], proc["target"]), (X, "C:\\cmd.exe"))
        self.assertIn("cmd /c dir", proc["details"])

    def test_sources_line_up_in_utc(self):
        csv = normalize(parse_csv((HEAD + "2026-03-14 11:00:00+01:00,h,FAILED_LOGIN,a,,,\n").encode()), "csv")
        win = normalize([evtx_rec(4625, "2026-03-14T09:59:00Z", TargetUserName="a")], "evtx")
        order = [e["source"] for e in build_timeline(csv + win)]
        self.assertEqual(order, ["PC", "h"])  # Windows 09:59 UTC comes before CSV 10:00 UTC


class ValidatorTests(unittest.TestCase):
    def check(self, text, expected, file_type="csv"):
        parse = parse_json if file_type == "json" else parse_csv
        result = validate(parse(text.encode()), file_type)
        self.assertEqual(result["state"], expected, result)
        return result

    def test_states(self):
        self.assertEqual(self.check(HEAD + "2026-03-14 10:00:00,h,FAILED_LOGIN,a,1.1.1.1,t,d\n", "recognized")["missing"], [])
        r = self.check("Timestamp,System,Activity,User,Target,Details\n2026-03-14 10:00:00,h,FAILED_LOGIN,a,t,d\n", "partial")
        self.assertEqual(r["missing"], ["Ip Address"])
        self.assertIn("group attempts by User", r["message"])
        self.check("Timestamp,Activity\n2026-03-14 10:00:00,FAILED_LOGIN\n", "partial")
        self.check("Activity,User\nFAILED_LOGIN,a\n", "unrecognized")
        self.check("Timestamp,User\n2026-03-14 10:00:00,a\n", "unrecognized")
        self.check(HEAD + "yesterday,h,FAILED_LOGIN,a,1.1.1.1,t,d\n", "unrecognized")

    def test_partial_details(self):
        r = self.check(HEAD + "yesterday,h,FAILED_LOGIN,a,1.1.1.1,t,d\n2026-03-14 10:00:00,h,FAILED_LOGIN,a,1.1.1.1,t,d\n", "partial")
        self.assertIn("left out", r["warnings"][0])
        r = self.check(HEAD + "2026-03-14 10:00:00,h,FILE_COPIED,a,1.1.1.1,t,d\n", "partial")
        self.assertIn("no detection rules can run", r["message"])
        r = self.check(HEAD + "2026-03-14 10:00:00,h,FAILED_LOGIN,a,1.1.1.1,t,d\n2026-03-14 10:01:00,h,FILE_COPIED,a,1.1.1.1,t,d\n", "recognized")
        self.assertIn("FILE_COPIED", r["warnings"][0])

    def test_time_zone_notice(self):
        r = self.check(HEAD + "2026-03-14 10:00:00,h,FAILED_LOGIN,a,1.1.1.1,t,d\n", "recognized")
        self.assertIn("treated as UTC", r["warnings"][0])

    def test_empty_and_evtx(self):
        self.assertEqual(validate([], "evtx")["state"], "unrecognized")
        self.assertEqual(validate([], "csv")["state"], "unrecognized")
        good = [evtx_rec(4624, "2026-03-14T10:00:00Z")]
        self.assertEqual(validate(good, "evtx")["state"], "recognized")
        self.assertEqual(validate(good + [evtx_rec(4624, "")], "evtx")["state"], "partial")


class SampleFileTests(unittest.TestCase):
    def pipeline(self, records, file_type):
        events = build_timeline(normalize(records, file_type))
        return validate(records, file_type), run_rules(events)

    def test_csv_and_json_samples_give_the_same_result(self):
        for records in (parse_csv(sample("csv", "brute_force_sample.csv")), parse_json(sample("json", "brute_force_sample.json"))):
            validation, findings = self.pipeline(records, "csv")
            self.assertEqual(validation["state"], "recognized")
            self.assertEqual([f["rule_id"] for f in findings], ["RULE_1"])

    def test_jsonl_sample(self):
        validation, findings = self.pipeline(parse_json(sample("json", "events.jsonl")), "json")
        self.assertEqual((validation["state"], len(findings)), ("recognized", 0))

    def test_partial_sample(self):
        validation, findings = self.pipeline(parse_csv(sample("csv", "partial_no_ip.csv")), "csv")
        self.assertEqual(validation["state"], "partial")
        self.assertEqual(len(findings), 0)  # only 2 failures

    def test_messy_sample(self):
        validation, findings = self.pipeline(parse_csv(sample("csv", "messy_rows.csv")), "csv")
        self.assertEqual(len(findings), 0)  # 3 failures but no successful login

    def check(self, name, state, expected_rules):
        records = parse_csv(sample("csv", name))
        validation, findings = self.pipeline(records, "csv")
        self.assertEqual(validation["state"], state, validation)
        self.assertEqual([(f["rule_id"], f["severity"]) for f in findings], expected_rules)
        return validation, findings

    def test_manual_test_files(self):
        self.check("privilege_abuse.csv", "recognized", [("RULE_2", "Medium")])
        self.check("data_activity.csv", "recognized", [("RULE_3", "Medium")])
        self.check("no_alerts_normal.csv", "recognized", [])
        self.check("unrecognized.csv", "unrecognized", [])
        self.check("full_attack_chain.csv", "recognized",
                   [("RULE_2", "High"), ("RULE_3", "Medium"), ("RULE_1", "Low")])
        validation, _ = self.check("bad_timestamps.csv", "partial", [])
        self.assertIn("2 of 4", validation["warnings"][0])

    def test_correlation_demo_files(self):
        """Multi-source scenario: 44 events, 4 systems, 3 timestamp styles, 3 findings, many decoys."""
        results = []
        for parse, name, ft in ((parse_csv, ("csv", "correlation_demo.csv"), "csv"),
                                (parse_json, ("json", "correlation_demo.json"), "json")):
            records = parse(sample(*name))
            raw_times = [parse_time(r["Timestamp"])[0] for r in records]
            self.assertNotEqual(raw_times, sorted(raw_times), "the raw file is not in time order")
            validation, findings = self.pipeline(records, ft)
            events = build_timeline(normalize(records, ft))
            self.assertEqual((validation["state"], len(events), len({e["source"] for e in events})), ("recognized", 44, 4))
            self.assertEqual([e["time"] for e in events], sorted(e["time"] for e in events))
            self.assertEqual(next(e for e in events if e["target"] == "Domain" and e["user"] == "jdoe")["timestamp"],
                             "2026-03-14 09:05:12")  # logged as 14:05:12+05:00
            self.assertEqual([(f["rule_id"], f["severity"], f["user"]) for f in findings],
                             [("RULE_2", "High", "jdoe"), ("RULE_1", "Medium", "jdoe"), ("RULE_3", "Medium", "jdoe")])
            chain = findings[0]
            self.assertEqual({e["source"] for e in chain["events"]}, {"vpn-gateway", "dc-01", "file-server-01"})
            self.assertEqual(findings[1]["event_count"], 7)   # 6 failures + the success
            self.assertEqual(findings[2]["event_count"], 10)  # 8 object accesses + 2 processes
            self.assertTrue(any("8 event(s) from system or service accounts" in n for n in findings.notes))
            results.append([(f["rule_id"], f["start"], f["end"]) for f in findings])
        self.assertEqual(results[0], results[1], "CSV and JSON must give identical findings")


if __name__ == "__main__":
    unittest.main()
