"""Tests the layout of the PDF report. Run from the project root:  python -m unittest discover -s test_data -v"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from reportlab.platypus import PageBreak                      # noqa: E402
from parsers.csv_parser import parse_csv                      # noqa: E402
from processing.correlation import run_rules                  # noqa: E402
from processing.normalizer import normalize                   # noqa: E402
from processing.timeline import build_timeline                # noqa: E402
from processing.validator import validate                     # noqa: E402
from reports.pdf_report import build_pdf, build_story         # noqa: E402


def analyze(name):
    with open(os.path.join(ROOT, "test_data", "csv", name), "rb") as f:
        records = parse_csv(f.read())
    events = build_timeline(normalize(records, "csv"))
    return events, run_rules(events), validate(records, "csv")


class ReportTests(unittest.TestCase):
    def check_timeline_starts_new_page(self, events, findings, validation):
        story = build_story(events, findings, validation, "x.csv")
        position = next(i for i, flowable in enumerate(story) if getattr(flowable, "text", "") == "Event timeline")
        self.assertIsInstance(story[position - 1], PageBreak)

    def test_timeline_always_starts_on_a_new_page(self):
        for name in ("correlation_demo.csv", "brute_force_sample.csv", "no_alerts_normal.csv", "full_attack_chain.csv"):
            self.check_timeline_starts_new_page(*analyze(name))
        self.check_timeline_starts_new_page([], [], None)

    def test_pdf_builds_and_lists_every_event(self):
        events, findings, validation = analyze("correlation_demo.csv")
        pdf = build_pdf(events, findings, validation, "correlation_demo.csv")
        self.assertTrue(pdf.startswith(b"%PDF-"))
        self.assertEqual(len(events), 44)

    def test_evidence_events_are_shaded(self):
        events, findings, validation = analyze("correlation_demo.csv")
        story = build_story(events, findings, validation, "x.csv")
        timeline_table = story[-1]
        shaded = [c for c in timeline_table._bkgrndcmds if c[1][1] > 0]  # data rows only
        evidence = {id(e) for f in findings for e in f["all_events"]}
        self.assertEqual(len(shaded), len({id(e) for e in events} & evidence))
        self.assertGreater(len(shaded), 0)

    def test_big_timeline_is_complete(self):
        head = "Timestamp,System,Activity,User,Ip Address,Target,Details\n"
        text = head + "".join(f"2026-03-14 10:{i // 60 % 60:02d}:{i % 60:02d},h,OBJECT_ACCESS,u,,f{i},d\n" for i in range(1500))
        records = parse_csv(text.encode())
        events = build_timeline(normalize(records, "csv"))
        pdf = build_pdf(events, run_rules(events), validate(records, "csv"), "big.csv")
        self.assertTrue(pdf.startswith(b"%PDF-"))

    def test_finding_label_is_never_separated_from_its_table(self):
        events, findings, validation = analyze("full_attack_chain.csv")
        story = build_story(events, findings, validation, "x.csv")
        loose = [f for f in story if getattr(f, "text", "") == "Relevant events"]
        self.assertEqual(loose, [], "the label must live inside the finding's KeepTogether block")


if __name__ == "__main__":
    unittest.main()
