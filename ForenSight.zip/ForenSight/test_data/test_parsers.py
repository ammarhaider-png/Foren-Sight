"""Run from the project root:  python -m unittest discover -s test_data -v"""
import os
import sys
import types
import unittest
from unittest import mock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from parsers import ParseError, canonical_field          # noqa: E402
from parsers.csv_parser import parse_csv                  # noqa: E402
from parsers.json_parser import parse_json                # noqa: E402
from parsers.evtx_parser import (EVTX_MAGIC, parse_event_xml, parse_evtx,   # noqa: E402
                                 parse_timestamp)

HEAD = "Timestamp,System,Activity,User,Ip Address,Target,Details\n"
ROW = "2026-03-14 10:02:10,web-01,FAILED_LOGIN,jdoe,192.168.1.25,SSH,Invalid password\n"


def sample(*parts):
    return os.path.join(ROOT, "test_data", *parts)


class CsvTests(unittest.TestCase):
    def test_sample_file(self):
        with open(sample("csv", "brute_force_sample.csv"), "rb") as f:
            r = parse_csv(f.read())
        self.assertEqual(len(r), 4)
        self.assertEqual(r[0]["Activity"], "FAILED_LOGIN")
        self.assertEqual(r[3]["Activity"], "SUCCESSFUL_LOGIN")
        self.assertEqual(r[0]["_ref"], "line 2")
        self.assertEqual(r.warnings, [])

    def test_values_exact(self):
        r = parse_csv((HEAD + ROW).encode())
        self.assertEqual(r[0], {"Timestamp": "2026-03-14 10:02:10", "System": "web-01",
                                "Activity": "FAILED_LOGIN", "User": "jdoe", "Ip Address": "192.168.1.25",
                                "Target": "SSH", "Details": "Invalid password", "_ref": "line 2"})

    def test_bom_semicolon_and_case(self):
        text = "\ufeffTIMESTAMP; system ;Activity;user;IP  address;Target;Details\n2026-03-14 10:02:10;w;A;u;1.1.1.1;t;d\n"
        r = parse_csv(text.encode("utf-8"))
        self.assertEqual(r[0]["Ip Address"], "1.1.1.1")
        self.assertEqual(r[0]["Timestamp"], "2026-03-14 10:02:10")

    def test_utf16_and_cp1252(self):
        self.assertEqual(len(parse_csv((HEAD + ROW).encode("utf-16"))), 1)
        r = parse_csv((HEAD + ROW.replace("jdoe", "Zoë")).encode("cp1252"))
        self.assertEqual(r[0]["User"], "Zoë")
        self.assertTrue(any("Windows-1252" in w for w in r.warnings))

    def test_extra_columns_kept(self):
        r = parse_csv(("Timestamp,User,Session ID\n2026-03-14 10:00:00,jdoe,S-9\n").encode())
        self.assertEqual(r[0]["Session ID"], "S-9")

    def test_quoted_and_unquoted_commas(self):
        text = HEAD + ROW.replace("Invalid password", '"Invalid, quoted"') + ROW.replace("Invalid password", "Invalid, loose")
        r = parse_csv(text.encode())
        self.assertEqual(r[0]["Details"], "Invalid, quoted")
        self.assertEqual(r[1]["Details"], "Invalid, loose")
        self.assertEqual(len(r.warnings), 1)
        self.assertIn("extra values", r.warnings[0])

    def test_short_row_padded_with_warning(self):
        r = parse_csv((HEAD + "2026-03-14 10:00:00,web-01,FAILED_LOGIN,jdoe\n").encode())
        self.assertEqual(r[0]["Details"], "")
        self.assertIn("fewer values", r.warnings[0])

    def test_overlong_row_rejected_not_guessed(self):
        r = parse_csv("Timestamp,User,Details,Target\n1,2,3,4,5\n6,7,8,9\n".encode())
        self.assertEqual(len(r), 1)
        self.assertEqual(r.skipped, 1)
        self.assertIn("line 2", r.warnings[0])

    def test_blank_lines_and_line_numbers(self):
        r = parse_csv((HEAD + "\n" + ROW + "\n\n" + ROW).encode())
        self.assertEqual([x["_ref"] for x in r], ["line 3", "line 6"])
        self.assertEqual(r.total_seen, 2)

    def test_messy_sample(self):
        with open(sample("csv", "messy_rows.csv"), "rb") as f:
            r = parse_csv(f.read())
        self.assertEqual(len(r), 3)
        self.assertEqual(r[0]["Details"], "Invalid password, attempt 1")
        self.assertEqual(r[1]["Details"], "Invalid password, attempt 2")
        self.assertEqual(r[2]["Details"], "")

    def test_header_only(self):
        r = parse_csv(HEAD.encode())
        self.assertEqual(len(r), 0)
        self.assertIn("no data rows", r.warnings[0])

    def test_unreadable_files_raise(self):
        for bad in (b"", b"   \n  ", b"\x00\x01\x02binary", (HEAD.replace("User", "Activity")).encode()):
            with self.assertRaises(ParseError):
                parse_csv(bad)

    def test_multiline_quoted_field(self):
        r = parse_csv((HEAD + ROW.replace("Invalid password", '"two\nlines"')).encode())
        self.assertEqual(r[0]["Details"], "two\nlines")


class JsonTests(unittest.TestCase):
    def test_sample_file(self):
        with open(sample("json", "brute_force_sample.json"), "rb") as f:
            r = parse_json(f.read())
        self.assertEqual(len(r), 4)
        self.assertEqual(r[2]["_ref"], "event 3")
        self.assertEqual(r[3]["Activity"], "SUCCESSFUL_LOGIN")
        self.assertEqual(r.warnings, [])

    def test_json_lines(self):
        with open(sample("json", "events.jsonl"), "rb") as f:
            r = parse_json(f.read())
        self.assertEqual(len(r), 2)

    def test_single_object_and_wrapper(self):
        one = parse_json(b'{"Timestamp": "t", "User": "jdoe"}')
        self.assertEqual(len(one), 1)
        wrapped = parse_json(b'{"events": [{"User": "a"}, {"User": "b"}]}')
        self.assertEqual(len(wrapped), 2)
        self.assertIn("'events'", wrapped.warnings[0])

    def test_value_types(self):
        r = parse_json(b'{"Timestamp": 1773482530, "User": null, "Details": {"a": 1}, "Target": true}')
        self.assertEqual(r[0]["Timestamp"], "1773482530")
        self.assertEqual(r[0]["User"], "")
        self.assertEqual(r[0]["Details"], '{"a": 1}')
        self.assertEqual(r[0]["Target"], "true")

    def test_keys_case_and_extras(self):
        r = parse_json(b'[{"user": "jdoe", "ip address": "1.1.1.1", "Session": "S1"}]')
        self.assertEqual(r[0]["User"], "jdoe")
        self.assertEqual(r[0]["Ip Address"], "1.1.1.1")
        self.assertEqual(r[0]["Session"], "S1")

    def test_non_objects_skipped_with_warning(self):
        r = parse_json(b'[{"User": "a"}, 5, "x", {"User": "b"}]')
        self.assertEqual(len(r), 2)
        self.assertEqual(r.skipped, 2)
        self.assertIn("positions 2, 3", r.warnings[0])

    def test_errors(self):
        cases = [b"", b'[{"User": "a"},', b'{"User": "a", "User": "b"}', b'[{"User": "a", "user": "b"}]', b"42"]
        for bad in cases:
            with self.assertRaises(ParseError, msg=bad):
                parse_json(bad)

    def test_empty_list(self):
        r = parse_json(b"[]")
        self.assertEqual(len(r), 0)
        self.assertIn("no events", r.warnings[0])


XML_4625 = """<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event">
<System><Provider Name="Microsoft-Windows-Security-Auditing" Guid="{x}"/><EventID Qualifiers="">4625</EventID>
<TimeCreated SystemTime="2026-03-14 10:02:10.123456"/><EventRecordID>777</EventRecordID>
<Channel>Security</Channel><Computer>WIN-SRV01</Computer></System>
<EventData><Data Name="SubjectUserName">WIN-SRV01$</Data><Data Name="TargetUserName">jdoe</Data>
<Data Name="IpAddress">192.168.1.25</Data><Data>unnamed</Data></EventData></Event>"""


def event_xml(event_id, provider="Microsoft-Windows-Security-Auditing", record="1"):
    return (f'<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event"><System>'
            f'<Provider Name="{provider}"/><EventID>{event_id}</EventID>'
            f'<TimeCreated SystemTime="2026-03-14T10:02:10.1234567Z"/><EventRecordID>{record}</EventRecordID>'
            f'<Channel>Security</Channel><Computer>PC</Computer></System><EventData/></Event>')


class EvtxTests(unittest.TestCase):
    def test_event_xml(self):
        e = parse_event_xml(XML_4625)
        self.assertEqual(e["EventID"], 4625)
        self.assertEqual(e["Timestamp"], "2026-03-14T10:02:10.123456Z")
        self.assertEqual(e["Computer"], "WIN-SRV01")
        self.assertEqual(e["EventData"]["TargetUserName"], "jdoe")      # not the SubjectUserName machine account
        self.assertEqual(e["EventData"]["SubjectUserName"], "WIN-SRV01$")
        self.assertEqual(e["EventData"]["Data_4"], "unnamed")

    def test_bad_xml_rejected(self):
        for bad in ("<Event>", "<Event/>", '<!DOCTYPE x [<!ENTITY a "b">]><Event/>',
                    "<Event><System><EventID>abc</EventID></System></Event>"):
            with self.assertRaises(ValueError):
                parse_event_xml(bad)

    def test_timestamps(self):
        self.assertEqual(parse_timestamp("2026-03-14 10:02:10.123456"), "2026-03-14T10:02:10.123456Z")
        self.assertEqual(parse_timestamp("2026-03-14T10:02:10Z"), "2026-03-14T10:02:10.000000Z")
        self.assertEqual(parse_timestamp("2026-03-14T11:02:10+01:00"), "2026-03-14T10:02:10.000000Z")
        self.assertEqual(parse_timestamp("2026-03-14T08:02:10-0200"), "2026-03-14T10:02:10.000000Z")
        for bad in ("", "garbage", "2026-13-40 10:00:00", None):
            self.assertEqual(parse_timestamp(bad), "")

    def test_not_an_evtx(self):
        with self.assertRaises(ParseError):
            parse_evtx(b"Timestamp,User\n1,2\n")

    def test_missing_library(self):
        with mock.patch.dict(sys.modules, {"Evtx": None, "Evtx.Evtx": None}):
            with self.assertRaises(ParseError) as ctx:
                parse_evtx(EVTX_MAGIC + b"\x00" * 64)
        self.assertIn("python-evtx", str(ctx.exception))

    def test_filtering_and_error_reporting(self):
        class Rec:
            def __init__(self, xml): self.x = xml
            def xml(self):
                if isinstance(self.x, Exception):
                    raise self.x
                return self.x

        class Chunk:
            def __init__(self, items, break_after=None): self.items, self.break_after = items, break_after
            def records(self):
                for i, item in enumerate(self.items):
                    if self.break_after is not None and i == self.break_after:
                        raise RuntimeError("damaged chunk")
                    yield Rec(item)

        seen = {}

        class FakeEvtx:
            def __init__(self, path): seen["path"] = path; assert os.path.exists(path)
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def chunks(self):
                yield Chunk([event_xml(4624, record="1"), event_xml(4624, provider="Other-App", record="2"),
                             event_xml(9999, record="3"), RuntimeError("corrupt"), event_xml(4688, record="5")])
                yield Chunk([event_xml(4672, record="6"), event_xml(4663, record="7")], break_after=1)

        mod, pkg = types.ModuleType("Evtx.Evtx"), types.ModuleType("Evtx")
        mod.Evtx = FakeEvtx
        with mock.patch.dict(sys.modules, {"Evtx": pkg, "Evtx.Evtx": mod}):
            r = parse_evtx(EVTX_MAGIC + b"\x00" * 64)

        self.assertEqual([x["EventID"] for x in r], [4624, 4688, 4672])
        self.assertEqual([x["_ref"] for x in r], ["record 1", "record 5", "record 6"])
        self.assertEqual(r.total_seen, 6)  # the 7th record was lost inside the damaged chunk
        self.assertEqual(r.skipped, 3)
        joined = " ".join(r.warnings)
        self.assertIn("Ignored 2 of 6", joined)
        self.assertIn("1 event(s) could not be decoded", joined)
        self.assertIn("1 damaged section", joined)
        self.assertFalse(os.path.exists(seen["path"]), "temporary evidence copy must be deleted")


class HelperTests(unittest.TestCase):
    def test_canonical_field(self):
        self.assertEqual(canonical_field(" ip   ADDRESS "), "Ip Address")
        self.assertIsNone(canonical_field("src_ip"))


if __name__ == "__main__":
    unittest.main()
