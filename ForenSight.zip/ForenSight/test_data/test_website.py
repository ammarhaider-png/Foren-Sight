"""Tests the website itself: upload each sample file and check what the page shows.
Run from the project root:  python -m unittest discover -s test_data -v"""
import io
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import app as website  # noqa: E402

BRUTE, PRIV, DATA = b"Possible brute force", b"Possible privilege abuse", b"Suspicious data/object activity"

# file -> (status marker on the page, rules that must appear, in order)
EXPECTED = [
    ("csv/brute_force_sample.csv", b"status-recognized", [BRUTE]),
    ("csv/privilege_abuse.csv", b"status-recognized", [PRIV]),
    ("csv/data_activity.csv", b"status-recognized", [DATA]),
    ("csv/full_attack_chain.csv", b"status-recognized", [PRIV, DATA, BRUTE]),
    ("csv/no_alerts_normal.csv", b"status-recognized", []),
    ("csv/partial_no_ip.csv", b"status-partial", []),
    ("csv/bad_timestamps.csv", b"status-partial", []),
    ("csv/messy_rows.csv", b"status-recognized", []),
    ("json/brute_force_sample.json", b"status-recognized", [BRUTE]),
    ("json/events.jsonl", b"status-recognized", []),
    ("csv/correlation_demo.csv", b"status-recognized", [PRIV, BRUTE, DATA]),
    ("json/correlation_demo.json", b"status-recognized", [PRIV, BRUTE, DATA]),
]


class WebsiteTests(unittest.TestCase):
    def setUp(self):
        self.client = website.app.test_client()

    def upload(self, data, name):
        return self.client.post("/upload", data={"evidence": (io.BytesIO(data), name)},
                                content_type="multipart/form-data", follow_redirects=True).data

    def upload_sample(self, relative):
        with open(os.path.join(ROOT, "test_data", *relative.split("/")), "rb") as f:
            return self.upload(f.read(), relative.split("/")[-1])

    def test_pages_load(self):
        for path in ("/", "/upload", "/timeline", "/about", "/help"):
            self.assertEqual(self.client.get(path).status_code, 200, path)
        self.assertEqual(self.client.get("/results").status_code, 404)  # the Investigation page is gone

    def test_every_sample_file(self):
        for relative, marker, rules in EXPECTED:
            page = self.upload_sample(relative)
            self.assertIn(marker, page, relative)
            positions = [page.find(r) for r in rules]
            self.assertTrue(all(p >= 0 for p in positions), f"{relative}: missing {rules}")
            self.assertEqual(positions, sorted(positions), f"{relative}: findings out of order")
            for rule in (BRUTE, PRIV, DATA):
                if rule not in rules:
                    self.assertNotIn(rule, page, f"{relative}: unexpected {rule!r}")
            if not rules:
                self.assertIn(b"No alerts", page, relative)

    def test_unrecognized_file_is_rejected(self):
        page = self.upload_sample("csv/unrecognized.csv")
        self.assertIn(b"Unrecognized file", page)
        self.assertNotIn(b"Download PDF report", page)

    def test_json_lines_extensions_accepted(self):
        line = b'{"Timestamp": "2026-03-14 10:00:00", "Activity": "FAILED_LOGIN", "User": "jdoe"}\n'
        for name in ("a.jsonl", "a.ndjson", "A.JSONL"):
            self.assertNotIn(b"Unsupported file type", self.upload(line, name), name)

    def test_unsupported_and_unreadable_files(self):
        self.assertIn(b"Unsupported file type", self.upload(b"x", "notes.txt"))
        self.assertIn(b"not a valid Windows EVTX", self.upload(b"not an evtx", "fake.evtx"))
        self.assertIn(b"The file is empty", self.upload(b"", "empty.csv"))
        self.assertIn(b"not valid", self.upload(b'[{"User": "a"},', "broken.json"))

    def test_failed_upload_does_not_show_old_results(self):
        self.upload_sample("csv/brute_force_sample.csv")
        page = self.upload(b"x", "notes.txt")
        self.assertNotIn(b'id="results"', page)
        self.assertNotIn(b"Download PDF report", page)
        self.assertNotIn(b"Possible brute force", page)

    def test_timeline_lists_events_in_time_order(self):
        self.upload_sample("csv/full_attack_chain.csv")
        page = self.client.get("/timeline").data
        stamps = [s for s in page.decode().split("2026-03-14 ")[1:]]
        times = [s[:8] for s in stamps]
        self.assertEqual(len(times), 11)
        self.assertEqual(times, sorted(times))

    def test_pdf_download(self):
        self.assertEqual(self.client.get("/report.pdf").status_code, 302)  # nothing analyzed yet
        self.upload_sample("csv/full_attack_chain.csv")
        r = self.client.get("/report.pdf")
        self.assertEqual((r.status_code, r.mimetype), (200, "application/pdf"))
        self.assertTrue(r.data.startswith(b"%PDF-"))

    def test_analyze_page_explains_severity_not_validation(self):
        page = self.client.get("/upload").data
        for level in (b"sev-low", b"sev-medium", b"sev-high"):
            self.assertIn(level, page)
        self.assertNotIn(b"state-partial", page)

    def test_help_page_has_the_three_validation_cards(self):
        page = self.client.get("/help").data
        for card in (b"state-ok", b"state-partial", b"state-bad"):
            self.assertIn(card, page)
        self.assertNotIn(b"state-list", page)

    def test_hero_has_a_single_image_layer(self):
        page = self.client.get("/").data
        self.assertNotIn(b"hero-img", page)

    def test_tab_title_and_icon(self):
        self.assertIn(b"<title>ForenSight</title>", self.client.get("/").data)
        for path, title in (("/upload", b"Analyze | ForenSight"), ("/timeline", b"Timeline | ForenSight"),
                            ("/about", b"About | ForenSight"), ("/help", b"Help | ForenSight")):
            self.assertIn(b"<title>" + title + b"</title>", self.client.get(path).data, path)
        page = self.client.get("/").data
        self.assertIn(b"images/favicon.svg", page)
        for icon in ("/static/images/favicon.svg", "/static/images/favicon.png"):
            response = self.client.get(icon)
            response.close()
            self.assertEqual(response.status_code, 200, icon)


if __name__ == "__main__":
    unittest.main()
