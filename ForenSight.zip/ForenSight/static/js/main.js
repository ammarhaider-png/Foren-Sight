(function () {
  const input = document.getElementById('evidence-file');
  const form = document.getElementById('upload-form');
  if (!input || !form) return;

  const zone = document.querySelector('.dropzone');
  const title = document.querySelector('.drop-title');
  const detail = document.getElementById('file-name');
  const emptyTitle = title.textContent;
  const emptyDetail = detail.textContent;

  function readableSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  input.addEventListener('change', () => {
    if (input.files.length) {
      const file = input.files[0];
      title.textContent = 'File ready to analyze';
      detail.textContent = file.name + ' (' + readableSize(file.size) + '). Click to choose a different file.';
      zone.classList.add('has-file');
    } else {
      title.textContent = emptyTitle;
      detail.textContent = emptyDetail;
      zone.classList.remove('has-file');
    }
  });

  form.addEventListener('submit', () => {
    document.getElementById('progress').hidden = false;
    document.getElementById('analyze-btn').disabled = true;
  });
})();
