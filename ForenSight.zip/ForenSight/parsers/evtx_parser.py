"""Windows EVTX parser.

Returns one dict per supported Security event:
    {"EventID": 4624, "Provider": ..., "Channel": ..., "Computer": ..., "RecordID": ...,
     "Timestamp": "2026-03-14T10:02:10.123456Z" (UTC), "EventData": {field: value}, "_ref": "record N"}

Only Security-auditing events with a supported Event ID are returned, because the same
numeric ID can mean something else when it comes from another provider.
"""
import os
import re
import tempfile
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

from . import ParseError, ParsedRecords

SUPPORTED_EVENT_IDS = frozenset({4624, 4625, 4672, 4663, 4688})
SECURITY_PROVIDER = "microsoft-windows-security-auditing"
EVTX_MAGIC = b"ElfFile\x00"

_TIME = re.compile(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?\s*(Z|[+-]\d{2}:?\d{2})?$")


def parse_timestamp(value):
    """Windows SystemTime -> ISO-8601 UTC string, or '' if it cannot be read."""
    match = _TIME.match((value or "").strip())
    if not match:
        return ""
    year, month, day, hour, minute, second, fraction, zone = match.groups()
    try:
        moment = datetime(int(year), int(month), int(day), int(hour), int(minute), int(second),
                          int((fraction or "0")[:6].ljust(6, "0")), tzinfo=timezone.utc)
    except ValueError:
        return ""
    if zone and zone != "Z":
        digits = zone[1:].replace(":", "")
        offset = timedelta(hours=int(digits[:2]), minutes=int(digits[2:]))
        moment -= offset if zone[0] == "+" else -offset
    return moment.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def _text(parent, tag):
    node = parent.find(tag)
    return (node.text or "").strip() if node is not None else ""


def parse_event_xml(xml_text):
    """One event's XML -> dict. Raises ValueError if the XML is unusable."""
    if "<!DOCTYPE" in xml_text or "<!ENTITY" in xml_text:
        raise ValueError("unexpected DTD in event XML")
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise ValueError(str(exc)) from exc
    for element in root.iter():
        element.tag = element.tag.split("}", 1)[-1]  # drop the XML namespace

    system = root.find("System")
    if system is None:
        raise ValueError("no System section")
    try:
        event_id = int(_text(system, "EventID"))
    except ValueError:
        raise ValueError("no readable EventID") from None

    provider = system.find("Provider")
    time_created = system.find("TimeCreated")
    event_data = {}
    section = root.find("EventData")
    if section is not None:
        for position, item in enumerate(section.findall("Data"), 1):
            name = item.get("Name") or f"Data_{position}"
            if name in event_data:
                name = f"{name}_{position}"
            event_data[name] = (item.text or "").strip()

    return {
        "EventID": event_id,
        "Provider": provider.get("Name", "") if provider is not None else "",
        "Channel": _text(system, "Channel"),
        "Computer": _text(system, "Computer"),
        "RecordID": _text(system, "EventRecordID"),
        "Timestamp": parse_timestamp(time_created.get("SystemTime") if time_created is not None else ""),
        "EventData": event_data,
    }


def _read_log(evtx_class, path):
    records, total, ignored, unreadable, damaged, no_time = [], 0, 0, 0, 0, 0
    with evtx_class(path) as log:
        for chunk in log.chunks():
            try:
                for raw in chunk.records():
                    total += 1
                    try:
                        event = parse_event_xml(raw.xml())
                    except Exception:  # a corrupt record must not stop the rest of the file
                        unreadable += 1
                        continue
                    if event["EventID"] not in SUPPORTED_EVENT_IDS or event["Provider"].lower() != SECURITY_PROVIDER:
                        ignored += 1
                        continue
                    if not event["Timestamp"]:
                        no_time += 1
                    event["_ref"] = f"record {event['RecordID'] or '?'}"
                    records.append(event)
            except Exception:
                damaged += 1

    warnings = []
    if ignored:
        ids = ", ".join(str(i) for i in sorted(SUPPORTED_EVENT_IDS))
        warnings.append(f"Ignored {ignored:,} of {total:,} events because they are not supported "
                        f"Security events (supported Event IDs: {ids}).")
    if unreadable:
        warnings.append(f"{unreadable:,} event(s) could not be decoded and were skipped.")
    if damaged:
        warnings.append(f"{damaged} damaged section(s) of the log could not be read, so some events may be missing.")
    if no_time:
        warnings.append(f"{no_time} event(s) have no readable timestamp and cannot be placed on the timeline.")
    return ParsedRecords(records, warnings, total_seen=total, skipped=ignored + unreadable)


def parse_evtx(data):
    if not data.startswith(EVTX_MAGIC):
        raise ParseError("This is not a valid Windows EVTX file (the file header is missing or damaged).")
    try:
        from Evtx.Evtx import Evtx
    except ImportError as exc:
        raise ParseError("EVTX support needs the 'python-evtx' package. "
                         "Install it with: pip install python-evtx") from exc

    path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".evtx", delete=False) as tmp:
            tmp.write(data)
            path = tmp.name
        return _read_log(Evtx, path)
    finally:  # the evidence copy never outlives the request
        if path:
            try:
                os.remove(path)
            except OSError:
                pass
