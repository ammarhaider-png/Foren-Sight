"""CSV parser. Returns one dict per data row, keyed by column name."""
import csv
import io

from . import ParseError, ParsedRecords, canonical_field, decode_text, listed

csv.field_size_limit(5_000_000)


def _where(lines):
    return ("line " if len(lines) == 1 else "lines ") + listed(lines)


def _pick_delimiter(header_line):
    """Comma by default; semicolon/tab/pipe if the header clearly uses one (Excel locales)."""
    counts = {d: header_line.count(d) for d in (",", ";", "\t", "|")}
    best = max(counts, key=counts.get)
    return best if counts[best] else ","


def _build_header(raw_header):
    """Clean column names; expected ones become their exact canonical spelling."""
    names, seen = [], set()
    for i, raw in enumerate(raw_header, 1):
        raw = raw.replace("\ufeff", "").strip()
        canon = canonical_field(raw)
        name = canon or raw or f"column_{i}"
        if name in seen:
            if canon:
                raise ParseError(f"The column '{canon}' appears more than once in the header. "
                                 "Remove or rename the duplicate and upload again.")
            n = 2
            while f"{name}__{n}" in seen:
                n += 1
            name = f"{name}__{n}"
        seen.add(name)
        names.append(name)
    return names


def parse_csv(data):
    text, warnings = decode_text(data)
    first_line = next((ln for ln in text.splitlines() if ln.strip()), "")
    delimiter = _pick_delimiter(first_line)
    reader = csv.reader(io.StringIO(text, newline=""), delimiter=delimiter)

    records, total = [], 0
    padded, merged, rejected = [], [], []
    try:
        header = next((row for row in reader if any(c.strip() for c in row)), None)
        if header is None:
            raise ParseError("The CSV file has no header row.")
        names = _build_header(header)
        width = len(names)
        details_is_last = names[-1] == "Details"

        for row in reader:
            if not any(cell.strip() for cell in row):
                continue  # blank line
            total += 1
            line = reader.line_num
            if len(row) < width:
                padded.append(line)
                row = row + [""] * (width - len(row))
            elif len(row) > width:
                if details_is_last:  # typical cause: an unquoted comma inside Details
                    row = row[:width - 1] + [delimiter.join(row[width - 1:])]
                    merged.append(line)
                else:
                    rejected.append(line)
                    continue
            record = {name: value.strip() for name, value in zip(names, row)}
            record["_ref"] = f"line {line}"
            records.append(record)
    except csv.Error as exc:
        raise ParseError(f"The CSV file could not be read (near line {reader.line_num}): {exc}") from exc

    if padded:
        warnings.append(f"{len(padded)} row(s) had fewer values than the header ({_where(padded)}); "
                        "the missing values were left blank.")
    if merged:
        warnings.append(f"{len(merged)} row(s) had extra values ({_where(merged)}); the extras were "
                        "joined into the Details column. Put quotes around values that contain commas.")
    if rejected:
        warnings.append(f"{len(rejected)} row(s) had more values than the header ({_where(rejected)}) "
                        "and were skipped, because the extra values could not be placed safely.")
    if total == 0:
        warnings.append("The CSV file has a header but no data rows.")
    return ParsedRecords(records, warnings, total_seen=total, skipped=len(rejected))
