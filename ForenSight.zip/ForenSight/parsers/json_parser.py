"""JSON parser. Accepts a list of event objects, one event object, or JSON Lines."""
import json

from . import ParseError, ParsedRecords, canonical_field, decode_text, listed


def _no_duplicate_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f"duplicate key '{key}'")
        obj[key] = value
    return obj


def _load(text):
    """Whole-document JSON first; if that fails, try JSON Lines (one object per line)."""
    try:
        return json.loads(text, object_pairs_hook=_no_duplicate_keys)
    except json.JSONDecodeError as first_error:
        lines = [ln for ln in text.splitlines() if ln.strip()]
        try:
            return [json.loads(ln, object_pairs_hook=_no_duplicate_keys) for ln in lines]
        except ValueError:
            raise ParseError(f"The JSON file is not valid (line {first_error.lineno}, "
                             f"column {first_error.colno}): {first_error.msg}.") from first_error
    except ValueError as exc:  # duplicate key
        raise ParseError(f"The JSON file has a {exc}. Each event must use unique field names.") from exc
    except RecursionError as exc:
        raise ParseError("The JSON file is nested too deeply to read.") from exc


def _find_events(doc, warnings):
    if isinstance(doc, list):
        return doc
    if isinstance(doc, dict):
        if not any(canonical_field(k) for k in doc):
            wrapped = [(k, v) for k, v in doc.items()
                       if isinstance(v, list) and v and all(isinstance(i, dict) for i in v)]
            if len(wrapped) == 1:
                warnings.append(f"Read the events from the '{wrapped[0][0]}' key of the JSON object.")
                return wrapped[0][1]
        return [doc]
    raise ParseError("The JSON file must contain an event object or a list of event objects.")


def _to_text(value):
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    return json.dumps(value, ensure_ascii=False)  # numbers, booleans, nested objects


def parse_json(data):
    text, warnings = decode_text(data)
    events = _find_events(_load(text), warnings)

    records, not_objects = [], []
    for index, event in enumerate(events, 1):
        if not isinstance(event, dict):
            not_objects.append(index)
            continue
        record = {}
        for key, value in event.items():
            canon = canonical_field(key)
            if canon is None:
                record[str(key)] = value  # unknown fields are kept untouched
                continue
            if canon in record:
                raise ParseError(f"Event {index} contains the field '{canon}' twice "
                                 "(for example 'User' and 'user'). Use one name per field.")
            record[canon] = _to_text(value)
        record["_ref"] = f"event {index}"
        records.append(record)

    if not_objects:
        warnings.append(f"{len(not_objects)} item(s) were not event objects (positions {listed(not_objects)}) "
                        "and were skipped.")
    if not events:
        warnings.append("The JSON file contains no events.")
    return ParsedRecords(records, warnings, total_seen=len(events), skipped=len(not_objects))
