"""Parsers: raw uploaded bytes -> raw records.

    parse_csv(data) / parse_json(data) / parse_evtx(data)  ->  ParsedRecords

A parser reads faithfully. It never guesses, never invents a value and never
drops anything silently: whatever it skips, repairs or cannot decode is counted
and described in ParsedRecords.warnings so the user can see it.

Interpretation (which Event ID means what, time zones, "-" placeholders, rule
logic) belongs to the validator, normalizer and correlation modules.
"""
import codecs
import re

# The seven columns/keys a CSV or JSON file may contain (controlled schema).
EXPECTED_FIELDS = ("Timestamp", "System", "Activity", "User", "Ip Address", "Target", "Details")
_CANONICAL = {name.lower(): name for name in EXPECTED_FIELDS}


class ParseError(Exception):
    """The file cannot be read at all. The message is shown to the user."""


class ParsedRecords(list):
    """A plain list of record dicts that also carries what happened while reading."""

    def __init__(self, records=(), warnings=None, total_seen=0, skipped=0):
        super().__init__(records)
        self.warnings = list(warnings or [])
        self.total_seen = total_seen  # records/rows/events examined
        self.skipped = skipped        # examined but not returned


def canonical_field(name):
    """Map a header/key to one of the seven expected names, or None.

    Only case and spacing are forgiven ('ip address', ' IP  Address ').
    Synonyms such as 'src' or 'client_ip' are deliberately NOT guessed.
    """
    key = re.sub(r"\s+", " ", str(name).replace("\ufeff", "")).strip().lower()
    return _CANONICAL.get(key)


def decode_text(data):
    """bytes -> (text, warnings). Raises ParseError for empty or binary input."""
    if not data or not data.strip():
        raise ParseError("The file is empty.")
    warnings = []
    try:
        if data.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
            text = data.decode("utf-16")
        else:
            try:
                text = data.decode("utf-8-sig")
            except UnicodeDecodeError:
                try:
                    text = data.decode("cp1252")
                except UnicodeDecodeError:
                    text = data.decode("latin-1")
                warnings.append("The file is not valid UTF-8, so it was read as Windows-1252. "
                                "Accented or special characters may look different.")
    except UnicodeDecodeError as exc:
        raise ParseError("The text encoding of this file could not be read.") from exc
    if "\x00" in text:
        raise ParseError("This file contains binary data, so it does not look like a text log.")
    return text, warnings


def listed(numbers, limit=5):
    """[7, 9, 15, 20, 21, 30] -> '7, 9, 15, 20, 21, ...'"""
    shown = ", ".join(str(n) for n in numbers[:limit])
    return shown + (", ..." if len(numbers) > limit else "")
